package com.fourk.app.sos;

import com.fourk.app.sos.util.SystemUiHider;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

public class Acs extends Activity {
    private static final boolean AUTO_HIDE = true;
    private static final int AUTO_HIDE_DELAY_MILLIS = 3000;
    private static final boolean TOGGLE_ON_CLICK = true;
    private static final int HIDER_FLAGS = SystemUiHider.FLAG_HIDE_NAVIGATION;
    private SystemUiHider mSystemUiHider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_acs);
        final EditText _phone = (EditText) findViewById(R.id.textPhone);
        final EditText _name = (EditText) findViewById(R.id.textName);

        findViewById(R.id.btnAdd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                final ContactRepo repo = new ContactRepo(getApplicationContext());
                Contact contact = new Contact();
                contact.contact_phone= _phone.getText().toString();
                contact.contact_name= _name.getText().toString();
                try{
                    repo.insert(contact);
                    Toast.makeText(getApplicationContext(), "New Contact Added", Toast.LENGTH_SHORT).show();
                }
                catch (Exception ex){
                    try {
                        repo.update(contact);
                        Toast.makeText(getApplicationContext(), "Contact updated", Toast.LENGTH_SHORT).show();
                    }
                    catch(Exception ex1){
                        Toast.makeText(getApplicationContext(), ex1.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }}
                catch (Exception x){
                    Toast.makeText(getApplicationContext(), x.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }
}

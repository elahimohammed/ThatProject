package com.fourk.app.sos;

/**
 * Created by Admin on 3/5/2015.
 */
public class Contact {
    public static final String TABLE = "Contact";
    public static final String KEY_name = "name";
    public static final String KEY_phone = "phone";
    public String contact_name;
    public String contact_phone;
}

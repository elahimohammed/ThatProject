package com.fourk.app.sos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Admin on 3/4/2015.
 */
public class ContactRepo {
    private MyDBHelper dbHelper;
    private Context _context;
    public ContactRepo(Context context) {
        try {
            _context = context;
            dbHelper = new MyDBHelper(context);
        }
        catch (Exception ex){
            Toast.makeText(context, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public int insert(Contact contact) {
        try {
            //Open connection to write data
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Contact.KEY_phone, contact.contact_phone);
            values.put(Contact.KEY_name, contact.contact_name);

            // Inserting Row
            long contact_Id = db.insert(Contact.TABLE, null, values);
            db.close(); // Closing database connection
            return (int) contact_Id;
        }
        catch (Exception ex){
            Toast.makeText(_context, ex.getMessage(), Toast.LENGTH_LONG).show();
            return 0;
        }
    }
    public String getLastLocation(){
        try {
            String latlng = "";
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            String selectQuery = "SELECT  " +
                    LocationData.KEY_lat + "," +
                    LocationData.KEY_lon +
                    " FROM " + LocationData.TABLE;
            Cursor cursor = db.rawQuery(selectQuery, null);

            if (cursor.moveToFirst()) {
                latlng = cursor.getString(cursor.getColumnIndex(LocationData.KEY_lat)) + "|" +
                        cursor.getString(cursor.getColumnIndex(LocationData.KEY_lon));
            }
            cursor.close();
            db.close();
            return latlng;
        }
        catch (Exception ex){
            Toast.makeText(_context, ex.getMessage(), Toast.LENGTH_LONG).show();
            return "";
        }
    }
    public int LastLocationUpdate(LocationData location) {
        try{
        SQLiteDatabase _db = dbHelper.getWritableDatabase();
        _db.delete(LocationData.TABLE, null, null);
        _db.close(); // Closing database connection

        //Open connection to write data
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(LocationData.KEY_lat,location.lat);
        values.put(LocationData.KEY_lon, location.lon);

        // Inserting Row
        long location_Id = db.insert(LocationData.TABLE, null, values);
        db.close(); // Closing database connection
        return (int) location_Id;
        }
        catch(Exception ex){
            Toast.makeText(_context, ex.getMessage(), Toast.LENGTH_LONG).show();
            return 0;
        }
    }

    public void delete(String contact_Name) {
        try{
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // It's a good practice to use parameter ?, instead of concatenate string
        db.delete(Contact.TABLE, Contact.KEY_name + "= ?", new String[] { String.valueOf(contact_Name) });
        db.close(); // Closing database connection
        }
        catch(Exception ex){
            Toast.makeText(_context, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void update(Contact contact) {
        try {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Contact.KEY_phone, contact.contact_phone);
            // It's a good practice to use parameter ?, instead of concatenate string
            db.update(Contact.TABLE, values, Contact.KEY_name + "= ?", new String[]{String.valueOf(contact.contact_name)});
            db.close(); // Closing database connection
        }
        catch (Exception ex){
            Toast.makeText(_context, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public ArrayList<HashMap<String, String>> getContactList() {
        //Open connection to read only
        try {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            String selectQuery = "SELECT  " +
                    Contact.KEY_name + "," +
                    Contact.KEY_phone +
                    " FROM " + Contact.TABLE;

            ArrayList<HashMap<String, String>> contactList = new ArrayList<HashMap<String, String>>();

            Cursor cursor = db.rawQuery(selectQuery, null);
            // looping through all rows and adding to list

            if (cursor.moveToFirst()) {
                do {
                    HashMap<String, String> contact = new HashMap<String, String>();
                    contact.put("name", cursor.getString(cursor.getColumnIndex(Contact.KEY_name)));
                    contact.put("phone", cursor.getString(cursor.getColumnIndex(Contact.KEY_phone)));
                    contactList.add(contact);
                } while (cursor.moveToNext());
            }

            cursor.close();
            db.close();
            return contactList;
        }
        catch(Exception ex){
            Toast.makeText(_context, ex.getMessage(), Toast.LENGTH_LONG).show();
            return null;
        }

    }

    public Contact getContactByNo(String Id){
        try {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            String selectQuery = "SELECT  " +
                    Contact.KEY_name + "," +
                    Contact.KEY_phone +
                    " FROM " + Contact.TABLE
                    + " WHERE " +
                    Contact.KEY_phone + "=?";// It's a good practice to use parameter ?, instead of concatenate string

            int iCount = 0;
            Contact contact = new Contact();

            Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(Id)});

            if (cursor.moveToFirst()) {
                do {
                    contact.contact_name = cursor.getString(cursor.getColumnIndex(Contact.KEY_name));
                    contact.contact_phone = cursor.getString(cursor.getColumnIndex(Contact.KEY_phone));

                } while (cursor.moveToNext());
            }

            cursor.close();
            db.close();
            return contact;
        }
        catch (Exception ex){
            Toast.makeText(_context, ex.getMessage(), Toast.LENGTH_LONG).show();
            return null;
        }
    }
}

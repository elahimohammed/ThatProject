package com.fourk.app.sos;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class Home extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
            setContentView(R.layout.activity_home);
            findViewById(R.id.cnt).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(getBaseContext(), Acs.class);
                    startActivity(i);
                }
            });
            findViewById(R.id.loc).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "Under Construction", Toast.LENGTH_LONG).show();
                }
            });
            findViewById(R.id.scream).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                    // create class object
                    GPSTracker gps = new GPSTracker(Home.this);
                    // check if GPS enabled
                    if(gps.canGetLocation()){
                        double latitude = gps.getLatitude();
                        double longitude = gps.getLongitude();
                        Geocoder geocoder;
                        geocoder = new Geocoder(Home.this, Locale.getDefault());
                        try {
                            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
                            String address = "";
                            for (int i = 0; i < addresses.toArray().length; i++) {
                                address = address + addresses.get(i).getAddressLine(0) + "," +
                                        addresses.get(i).getAddressLine(1) + "," +
                                        addresses.get(i).getAddressLine(2);
                            }
                            SendTextMessage(address);
                        } catch (Exception exe) {
                            Toast.makeText(Home.this, exe.getMessage(), Toast.LENGTH_SHORT).show();
                            SendTextMessage("Latitude:" + String.valueOf(latitude) + ", Longitude:" + String.valueOf(longitude));
                        }
                    }else{
                        gps.showSettingsAlert();
                    }
                    }
                    catch (Exception ex){
                        Toast.makeText(getApplicationContext(), "Error:" + ex.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
        catch (Exception ex){
            Toast.makeText(getApplicationContext(), ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    private void SendTextMessage(String address) {
        try{
        ContactRepo repo = new ContactRepo(getApplicationContext());
        ArrayList<HashMap<String, String>> contactList =  repo.getContactList();
            if(contactList.size()!=0){
                String list="";
                boolean err = false;
                String ErrorNo="Cannot Send to ";
                for (int a =0; a<contactList.size();a++)
                {
                    HashMap<String, String> tmpData = (HashMap<String, String>) contactList.get(a);
                    Set<String> key = tmpData.keySet();
                    Iterator it = key.iterator();
                    String name ="";
                    String phone="";
                    while (it.hasNext()) {
                        String hmKey = (String)it.next();
                        String hmData = tmpData.get(hmKey);
                        if(hmKey.equals("name")){
                            name = hmData;
                        }
                        if(hmKey.equals("phone")){
                            phone = hmData;
                            if(phone.length()==10){
                                phone = "0" + phone;
                            }
                        }
                        it.remove();
                    }
                    String message = "Hi "+ name + " ! I am in danger. Please find me at " + address;
                    try {
                        SmsManager smsManager = SmsManager.getDefault();
                        if((phone.startsWith("0")) && (phone.length()==11)){
                            smsManager.sendTextMessage(phone, null, message, null, null);
                        }
                        else if((phone.startsWith("+91"))&&(phone.length()==13)) {
                            smsManager.sendTextMessage(phone, null, message, null, null);
                        }
                        else{
                            err = true;
                            ErrorNo = ErrorNo + phone +",";
                        }
                        Toast.makeText(getApplicationContext(), "SMS sent.",
                                Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(),
                                "SMS failed, please try again. " + e.getMessage(),
                                Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                    if(err){
                        Toast.makeText(getApplicationContext(),
                                ErrorNo,
                                Toast.LENGTH_LONG).show();
                    }
                }
            }
            else{
                Toast.makeText(getApplicationContext(),
                        "SMS failed, No contact found ",
                        Toast.LENGTH_LONG).show();
            }
        }
        catch(Exception ee){
            Toast.makeText(getApplicationContext(), ee.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }
}

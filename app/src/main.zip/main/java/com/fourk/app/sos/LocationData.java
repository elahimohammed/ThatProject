package com.fourk.app.sos;

/**
 * Created by Admin on 3/5/2015.
 */
public class LocationData {
    public static final String TABLE = "Location";
    public static final String KEY_lat = "lat";
    public static final String KEY_lon = "lon";
    public String lat;
    public String lon;
}
